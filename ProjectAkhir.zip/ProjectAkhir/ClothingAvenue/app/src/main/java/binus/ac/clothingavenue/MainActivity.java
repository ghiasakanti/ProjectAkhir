package binus.ac.clothingavenue;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText TF1, TF2;
    Button Proceed;
    TextView Output1, HargaKaos, HargaKemeja;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TF1 = findViewById(R.id.TF1);
        TF2 = findViewById(R.id.TF2);
        Proceed = findViewById(R.id.Proceed);
        Output1 = findViewById(R.id.Output1);
        HargaKaos = findViewById(R.id.HargaKaos);
        HargaKemeja = findViewById(R.id.HargaKemeja);

        Proceed.setOnClickListener((v){

            double TFA = Double.parseDouble(TF1.getText().toString());
            double TFB = Double.parseDouble(TF2.getText().toString());
            double Harga1 = Double.parseDouble(HargaKaos.getText().toString());
            double Harga2 = Double.parseDouble(HargaKemeja.getText().toString());

            double HargaA = Harga1;
            double HargaB = Harga2;
            double TF = TFA;
            double TF1 = TFB;

            double Jumlah = (TF * HargaA) + (TF1 * HargaB);

            Output1.setText(Double.toString(Jumlah));
        });
    }
}
